import React, {Component} from "react";
import {BrowserRouter as Router, Link, Route,Routes} from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

import CreateTodo from "./components/create-todo";
import EditTodo from "./components/edit-todo.component";
import TodosList from "./components/todos-list.component";

import logo from "./logo.svg";

class App extends Component {
  render() {
    return (
     <Router>
      <div className="container">
        
<nav className="navbar-expand-lg navbar-light bg-light">
< a className="navbar-brand" href="https://codingthesmartway.com" target="blank">
  <img src={logo} width="30" height="30" alt="CodingThesmartway.com"/>
  </a>
<Link to="/" className="navbar-brand">MERN-Stack App</Link>
<div className=" nav-collapse">
  <ul className="navbar-nav mr-auto">
    <li className="navbar-item">
      <Link to="/" className="nav-link">Todos</Link>
    </li>
    <li className="navbar-item">
      <Link to="create/" className="nav-link">Create Todo</Link>
    </li>
  </ul>
</div>
</nav>


        <Routes>
        <Route path="/" exact="true" element={<TodosList />} />
        <Route exact path="/edit/:id" element={<EditTodo />} />
        {/* <Route exact path="/details/:id" render={(props) => <EditTodo {...props} /> } /> */}

        <Route path="/create" element={<CreateTodo />} />
        </Routes>
      </div>
     </Router>
    );   
  }
}

export default App;
